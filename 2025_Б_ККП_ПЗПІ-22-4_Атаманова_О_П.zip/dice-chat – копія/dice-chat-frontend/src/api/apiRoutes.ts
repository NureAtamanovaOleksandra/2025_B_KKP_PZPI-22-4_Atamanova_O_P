const API_ROUTES = Object.freeze({
  AUTH: {
    REGISTER: "/auth/register",
    LOGIN: "/auth/login",
  },
  USERS: {
    ME: "/users/me",
  },
  CHAT: {
    BASE: "/chats",
    MESSAGES: "/messages",
    AI: "/ai/chat",
  },
});

export default API_ROUTES;
