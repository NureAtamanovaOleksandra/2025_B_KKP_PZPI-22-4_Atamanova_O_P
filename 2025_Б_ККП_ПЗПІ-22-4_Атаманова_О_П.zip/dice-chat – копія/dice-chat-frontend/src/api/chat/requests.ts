import API_ROUTES from "../apiRoutes";
import { Chat, Message } from "./types";
import { axiosInstance } from "../../config/axios";

export const getAllChats = async (): Promise<Chat[]> => {
  const response = await axiosInstance.get(API_ROUTES.CHAT.BASE);
  return response.data;
};

export const getChat = async (id: string): Promise<Chat> => {
  const response = await axiosInstance.get(`${API_ROUTES.CHAT.BASE}/${id}`);
  return response.data;
};

export const getMessages = async (chatId: string): Promise<Message[]> => {
  const response = await axiosInstance.get(
    `${API_ROUTES.CHAT.MESSAGES}/chat/${chatId}`
  );
  return response.data;
};
