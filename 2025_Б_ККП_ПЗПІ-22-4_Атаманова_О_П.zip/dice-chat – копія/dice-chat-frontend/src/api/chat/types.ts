export interface Chat {
  _id: string;
  title: string;
  aiModel: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  _id: string;
  role: string;
  content: string;
  chat: string;
  createdAt: string;
}

export interface CreateChatRequest {
  title: string;
  aiModel?: string;
}

export interface UpdateChatRequest {
  title?: string;
  aiModel?: string;
}

export interface SendMessageRequest {
  chatId: string;
  messages: Message[];
} 