import API_ROUTES from "../apiRoutes";
import {
  Chat,
  Message,
  CreateChatRequest,
  UpdateChatRequest,
  SendMessageRequest,
} from "./types";
import { axiosInstance } from "../../config/axios";

export const createChat = async (data: CreateChatRequest): Promise<Chat> => {
  const response = await axiosInstance.post(API_ROUTES.CHAT.BASE, data);
  return response.data;
};

export const updateChat = async (
  id: string,
  data: UpdateChatRequest
): Promise<Chat> => {
  const response = await axiosInstance.put(
    `${API_ROUTES.CHAT.BASE}/${id}`,
    data
  );
  return response.data;
};

export const deleteChat = async (id: string): Promise<void> => {
  await axiosInstance.delete(`${API_ROUTES.CHAT.BASE}/${id}`);
};

export const sendMessage = async (
  data: SendMessageRequest
): Promise<Message> => {
  const response = await axiosInstance.post(API_ROUTES.CHAT.AI, data);
  return response.data;
};
