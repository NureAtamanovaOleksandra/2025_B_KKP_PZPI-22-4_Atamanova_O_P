import { axiosInstance } from "../../../config/axios";
import API_ROUTES from "../../apiRoutes";
import { User } from "./types";

const getCurrentUser = async (): Promise<User> => {
  const response = await axiosInstance.get<User>(API_ROUTES.USERS.ME);
  return response.data;
};

export default getCurrentUser; 