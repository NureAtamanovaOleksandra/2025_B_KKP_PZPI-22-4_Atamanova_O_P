import { axiosInstance } from "../../../config/axios";
import API_ROUTES from "../../apiRoutes";
import { LoginRequest, LoginResponse } from "./types";

const login = async (data: LoginRequest): Promise<LoginResponse> => {
  const response = await axiosInstance.post<LoginResponse>(
    API_ROUTES.AUTH.LOGIN,
    data
  );
  return response.data;
};

export default login; 