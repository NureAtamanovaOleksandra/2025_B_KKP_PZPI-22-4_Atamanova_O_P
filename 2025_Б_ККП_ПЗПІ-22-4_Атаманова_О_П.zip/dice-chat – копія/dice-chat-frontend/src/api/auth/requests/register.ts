import { axiosInstance } from "../../../config/axios";
import API_ROUTES from "../../apiRoutes";
import { RegisterRequest, RegisterResponse } from "./types";

const register = async (data: RegisterRequest): Promise<RegisterResponse> => {
  const response = await axiosInstance.post<RegisterResponse>(
    API_ROUTES.AUTH.REGISTER,
    data
  );
  return response.data;
};

export default register;
