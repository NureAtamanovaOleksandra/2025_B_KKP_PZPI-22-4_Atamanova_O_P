import { useMutation } from "@tanstack/react-query";
import { useAuthStore } from "../../../store/authStore";
import { register, RegisterRequest, RegisterResponse } from "../requests";

const useRegisterMutation = () => {
  const setIsLoggedIn = useAuthStore((state) => state.setIsLoggedIn);
  const setUser = useAuthStore((state) => state.setUser);

  return useMutation<RegisterResponse, Error, RegisterRequest>({
    mutationFn: register,
    onSuccess: (response) => {
      setIsLoggedIn(true);
      setUser({
        _id: response._id,
        email: response.email,
      });
    },
  });
};

export default useRegisterMutation;
