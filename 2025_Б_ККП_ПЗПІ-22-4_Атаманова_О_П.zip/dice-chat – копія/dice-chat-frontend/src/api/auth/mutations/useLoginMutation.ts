import { useMutation } from "@tanstack/react-query";
import { useAuthStore } from "../../../store/authStore";
import {
  login,
  getCurrentUser,
  LoginRequest,
  LoginMutationResponse,
} from "../requests";
import { setCookie, COOKIE_NAMES } from "../../../utils";

const useLoginMutation = () => {
  const setIsLoggedIn = useAuthStore((state) => state.setIsLoggedIn);
  const setUser = useAuthStore((state) => state.setUser);

  return useMutation<LoginMutationResponse, Error, LoginRequest>({
    mutationFn: async (data) => {
      const loginResponse = await login(data);
      setCookie(COOKIE_NAMES.ACCESS_TOKEN, loginResponse.accessToken);

      const user = await getCurrentUser();
      return { ...loginResponse, user };
    },
    onSuccess: (response) => {
      setIsLoggedIn(true);
      setUser(response.user);
    },
    onError: () => {
      setCookie(COOKIE_NAMES.ACCESS_TOKEN, "");
    },
  });
};

export default useLoginMutation;
