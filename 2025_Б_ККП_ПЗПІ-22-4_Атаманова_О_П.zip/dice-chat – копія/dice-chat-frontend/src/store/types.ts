export interface User {
  _id: string;
  email: string;
}

export interface AuthState {
  isLoggedIn: boolean;
  user: User | null;
  setIsLoggedIn: (isLoggedIn: boolean) => void;
  setUser: (user: User | null) => void;
}
