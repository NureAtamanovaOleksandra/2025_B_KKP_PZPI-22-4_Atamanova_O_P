const STORE_NAMES = {
  AUTH: "auth-storage",
};

export default STORE_NAMES;
