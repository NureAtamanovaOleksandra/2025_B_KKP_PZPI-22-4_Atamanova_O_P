import { create } from "zustand";
import { persist } from "zustand/middleware";
import { AuthState } from "./types";
import STORE_NAMES from "./storeNames";

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isLoggedIn: false,
      user: null,
      setIsLoggedIn: (isLoggedIn) => set({ isLoggedIn }),
      setUser: (user) => set({ user }),
    }),
    {
      name: STORE_NAMES.AUTH,
    }
  )
);
