import { create } from "zustand";

export interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

interface ChatState {
  chats: Chat[];
  currentChatId: string | null;
  isLoading: boolean;
  error: string | null;

  createNewChat: () => void;
  setCurrentChat: (chatId: string) => void;
  addMessage: (message: Message) => void;
  updateChatTitle: (chatId: string, title: string) => void;
  deleteChat: (chatId: string) => void;
}

type ChatStore = {
  set: (fn: (state: ChatState) => Partial<ChatState>) => void;
  get: () => ChatState;
};

export const useChatStore = create<ChatState>((set: ChatStore["set"]) => ({
  chats: [],
  currentChatId: null,
  isLoading: false,
  error: null,

  createNewChat: () => {
    const newChat: Chat = {
      id: crypto.randomUUID(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    set((state: ChatState) => ({
      chats: [newChat, ...state.chats],
      currentChatId: newChat.id,
    }));
  },

  setCurrentChat: (chatId: string) => {
    set((state: ChatState) => ({
      ...state,
      currentChatId: chatId,
    }));
  },

  addMessage: (message: Message) => {
    set((state: ChatState) => {
      const currentChat = state.chats.find(
        (chat: Chat) => chat.id === state.currentChatId
      );
      if (!currentChat) return state;

      const updatedChat = {
        ...currentChat,
        messages: [...currentChat.messages, message],
        updatedAt: new Date(),
      };

      return {
        ...state,
        chats: state.chats.map((chat: Chat) =>
          chat.id === state.currentChatId ? updatedChat : chat
        ),
      };
    });
  },

  updateChatTitle: (chatId: string, title: string) => {
    set((state: ChatState) => ({
      ...state,
      chats: state.chats.map((chat: Chat) =>
        chat.id === chatId ? { ...chat, title } : chat
      ),
    }));
  },

  deleteChat: (chatId: string) => {
    set((state: ChatState) => ({
      ...state,
      chats: state.chats.filter((chat: Chat) => chat.id !== chatId),
      currentChatId:
        state.currentChatId === chatId ? null : state.currentChatId,
    }));
  },
}));
