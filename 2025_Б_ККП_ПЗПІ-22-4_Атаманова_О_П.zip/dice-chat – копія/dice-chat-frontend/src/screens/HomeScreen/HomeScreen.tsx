import React, { useState, useEffect } from "react";
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  List,
  ListItem,
  ListItemText,
  Paper,
} from "@mui/material";
import {
  Chat,
  Message,
  getAllChats,
  getMessages,
  createChat,
  deleteChat,
  sendMessage,
} from "../../api";

export const HomeScreen: React.FC = () => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadChats();
  }, []);

  useEffect(() => {
    const oldBg = document.body.style.backgroundImage;
    const oldSize = document.body.style.backgroundSize;
    const oldRepeat = document.body.style.backgroundRepeat;
    const oldPosition = document.body.style.backgroundPosition;

    document.body.style.backgroundImage = "url('/images/lightTheme/parchment_background.png')";
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundRepeat = "no-repeat";
    document.body.style.backgroundPosition = "center";

    return () => {
      document.body.style.backgroundImage = oldBg;
      document.body.style.backgroundSize = oldSize;
      document.body.style.backgroundRepeat = oldRepeat;
      document.body.style.backgroundPosition = oldPosition;
    };
  }, []);

  const loadChats = async () => {
    try {
      setError(null);
      const response = await getAllChats();
      const loadedChats = Array.isArray(response) ? response : [];
      setChats(loadedChats);

      if (loadedChats.length > 0 && !selectedChat) {
        setSelectedChat(loadedChats[0]);
        loadMessages(loadedChats[0]._id);
      }
    } catch (error) {
      console.error("Error loading chats:", error);
      setError("Failed to load chats");
      setChats([]);
    }
  };

  const loadMessages = async (chatId: string) => {
    try {
      setError(null);
      const response = await getMessages(chatId);
      const loadedMessages = Array.isArray(response) ? response : [];
      setMessages(loadedMessages);
    } catch (error) {
      console.error("Error loading messages:", error);
      setError("Failed to load messages");
      setMessages([]);
    }
  };

  const handleCreateChat = async () => {
    try {
      setError(null);
      const newChat = await createChat({ title: "New Chat" });
      setChats((prevChats) => [...prevChats, newChat]);
      setSelectedChat(newChat);
      setMessages([]);
    } catch (error) {
      console.error("Error creating chat:", error);
      setError("Failed to create chat");
    }
  };

  const handleSelectChat = async (chat: Chat) => {
    setSelectedChat(chat);
    await loadMessages(chat._id);
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedChat) return;

    setIsLoading(true);
    try {
      setError(null);
      const updatedMessages = [
        ...messages,
        { role: "user", content: newMessage } as Message,
      ];

      const response = await sendMessage({
        chatId: selectedChat._id,
        messages: updatedMessages,
      });
      setMessages([...updatedMessages, response]);
      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
      setError("Failed to send message");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteChat = async (chatId: string) => {
    try {
      setError(null);
      await deleteChat(chatId);
      setChats((prevChats) => prevChats.filter((chat) => chat._id !== chatId));
      if (selectedChat?._id === chatId) {
        setSelectedChat(null);
        setMessages([]);
      }
    } catch (error) {
      console.error("Error deleting chat:", error);
      setError("Failed to delete chat");
    }
  };

  const handleLogout = () => {
    localStorage.clear();

    document.cookie
      .split(";")
      .forEach(
        (c) =>
          (document.cookie = c
            .replace(/^ +/, "")
            .replace(
              /=.*/,
              "=;expires=" + new Date().toUTCString() + ";path=/"
            ))
      );

    window.location.href = "/login";
  };

  return (
    <Container maxWidth="lg" sx={{ height: "100vh", py: 4, backgroundColor: "transparent" }}>
      <Box sx={{ display: "flex", height: "100%", gap: 2 }}>
        <Paper
          sx={{ width: 300, p: 2, display: "flex", flexDirection: "column"}}
        >
          <Typography
            variant="h1"
            align="center"
            fontSize={23}
            sx={{ mb: 2, fontFamily: "'Cinzel', serif", fontWeight: 400 }}
          >
            Chronicles of the Realm
          </Typography>
          <Button
            variant="contained"
            fullWidth
            onClick={handleCreateChat}
            sx={{ mb: 2 }}
          >
            New Chat
          </Button>
          {error && (
            <Typography color="error" sx={{ mb: 2 }}>
              {error}
            </Typography>
          )}
          <List sx={{ flex: 1, overflow: "auto" }}>
            {Array.isArray(chats) &&
              chats.map((chat) => (
                <ListItem
                  key={chat._id}
                  sx={{
                    cursor: "pointer",
                    bgcolor:
                      selectedChat?._id === chat._id
                        ? "action.selected"
                        : "transparent",
                    "&:hover": {
                      bgcolor: "action.hover",
                    },
                  }}
                  onClick={() => handleSelectChat(chat)}
                  secondaryAction={
                    <Button
                      size="small"
                      color="error"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteChat(chat._id);
                      }}
                    >
                      Delete
                    </Button>
                  }
                >
                  <ListItemText
                    primary={chat.title}
                    secondary={new Date(chat.updatedAt).toLocaleString()}
                  />
                </ListItem>
              ))}
          </List>
          <Button
            color="secondary"
            fullWidth
            sx={{ mt: 2 }}
            onClick={handleLogout}
          >
            Logout
          </Button>
        </Paper>

        <Paper sx={{ flex: 1, p: 2, display: "flex", flexDirection: "column" }}>
          {selectedChat ? (
            <>
              <Box sx={{ flex: 1, overflow: "auto", mb: 2 }}>
                {Array.isArray(messages) &&
                  messages.map((message, index) => (
                    <Box
                      key={index}
                      sx={{
                        mb: 2,
                        p: 2,
                        bgcolor:
                          message.role === "user"
                            ? "primary.light"
                            : "grey.100",
                        borderRadius: 1,
                        alignSelf:
                          message.role === "user" ? "flex-end" : "flex-start",
                      }}
                    >
                      <Typography
                        variant="body1"
                        sx={{ whiteSpace: "break-spaces" }}
                      >
                        {message.content}
                      </Typography>
                    </Box>
                  ))}
              </Box>
              <Box sx={{ display: "flex", gap: 1 }}>
                <TextField
                  fullWidth
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Type your message..."
                  disabled={isLoading}
                />
                <Button
                  variant="contained"
                  onClick={handleSendMessage}
                  disabled={isLoading || !newMessage.trim()}
                >
                  Send
                </Button>
              </Box>
            </>
          ) : (
            <Box
              sx={{
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Typography variant="h6" color="text.secondary">
                Select a chat or create a new one
              </Typography>
            </Box>
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default HomeScreen;