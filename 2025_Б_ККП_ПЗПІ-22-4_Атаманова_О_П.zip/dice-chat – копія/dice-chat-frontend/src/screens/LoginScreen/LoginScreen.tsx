import { Box, Typography, TextField, Button, Link, Stack } from "@mui/material";
import { Link as RouterLink } from "react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLoginMutation } from "../../api";
import { loginSchema, LoginFormData } from "../../schemas";
import { APP_ROUTES } from "../../app";
import styles from "./styles";

const LoginScreen = () => {
  const login = useLoginMutation();

  const {
    register: registerField,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormData) => {
    try {
      await login.mutateAsync(data);
    } catch (error) {
      // TODO: show error message in the UI
      console.error(error);
    }
  };

  return (
    <Box sx={styles.parchmentBackground} color="background.default">
      <Box sx={styles.dragonImage}></Box>
      <Box sx={styles.formContainer}>
        <Stack direction="column" spacing={2}>
          <Typography variant="h1" sx={styles.heading} color="text.primary">
            Welcome Back, Adventurer
          </Typography>

          <Typography variant="subtitle" color="text.primary">
            Re-enter the realm with your enchanted scroll and secret rune
          </Typography>
        </Stack>

        <Box component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={styles.fieldContainer}>
            <Box textAlign="left">
              <Box sx={styles.rowContainer}>
                <Typography
                  variant="label"
                  sx={styles.label}
                  color="text.primary"
                >
                  Scroll of Contact
                </Typography>
                <Typography variant="note" color="text.primary">
                  Present thy enchanted scroll (email)*
                </Typography>
              </Box>
              <TextField
                fullWidth
                placeholder="ex: adventurer@realmsmail.com"
                variant="outlined"
                sx={styles.textField}
                error={!!errors.email}
                helperText={errors.email?.message}
                {...registerField("email")}
              />
            </Box>

            <Box textAlign="left">
              <Box sx={styles.rowContainer}>
                <Typography
                  variant="label"
                  sx={styles.label}
                  color="text.primary"
                >
                  Secret Rune
                </Typography>
                <Typography variant="note" color="text.primary">
                  Whisper thy sacred word (password)*
                </Typography>
              </Box>
              <TextField
                fullWidth
                placeholder="Enter rune"
                type="password"
                variant="outlined"
                sx={styles.textField}
                error={!!errors.password}
                helperText={errors.password?.message}
                {...registerField("password")}
              />

              <Typography variant="note" color="text.primary">
                (Keep it safe from goblins!)
              </Typography>
            </Box>
          </Box>
          <Box sx={{ marginBottom: 2 }}>
            <Button
              fullWidth
              sx={styles.button}
              type="submit"
              disabled={login.isPending}
            >
              {login.isPending ? "Casting the spell..." : "ENTER THE REALM"}
            </Button>
            <Typography sx={styles.noteButton} color="text.primary">
              No soul sacrifice required*
            </Typography>
          </Box>
          <Typography variant="note" color="text.primary">
            New to the realm?{" "}
            <Link component={RouterLink} to={APP_ROUTES.REGISTER}>
              Join the Guild of Wanderers
            </Link>
          </Typography>
        </Box>
      </Box>
      <Box sx={styles.dragonOnTowerImage}></Box>
    </Box>
  );
};

export default LoginScreen;
