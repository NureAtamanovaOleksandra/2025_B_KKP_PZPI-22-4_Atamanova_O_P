import { Theme } from "@mui/material/styles";

const styles = {
  parchmentBackground: (theme: Theme) => ({
    backgroundImage: theme.images.parchmentBackground,
    backgroundSize: "cover",
    position: "fixed",
    inset: 0,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  }),

  formContainer: {
    maxWidth: 700,
    backgroundColor: "transparent",
    padding: 4,
    borderRadius: 0,
    boxShadow: "none", 
    display: "flex",
    flexDirection: "column",
    gap: 9,
    textAlign: "center",
    alignItems: "center",
  },

  fieldContainer: {
    display: "flex",
    flexDirection: "column",
    gap: 3,
  },

  rowContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },

  dragonImage: (theme: Theme) => ({
    position: "absolute",
    left: "5%",
    top: "5%",
    width: "500px",
    height: "500px",
    backgroundImage: theme.images.dragon,
    backgroundSize: "contain",
    backgroundRepeat: "no-repeat",
  }),

  dragonOnTowerImage: (theme: Theme) => ({
    position: "absolute",
    right: "-2%",
    bottom: "5%",
    width: "500px",
    height: "500px",
    backgroundImage: theme.images.dragonOnTower,
    backgroundSize: "contain",
    backgroundRepeat: "no-repeat",
  }),

  heading: {
    marginBottom: -2,
  },

  label: {
    fontWeight: "bold",
    textAlign: "left",
    marginBottom: 1,
  },

  textField: {
    width: "100%",
    marginBottom: 1,
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        border: "none",
      },
    },
    "& input": {
      fontFamily: "Crimson Pro",
    },
  },

  legal: {
    fontFamily: "Crimson Pro",
    fontSize: 16,
    textAlign: "left",
    width: "500px",
    marginTop: 7.5,
    marginBottom: 3,
  },

  button: {
    fontFamily: "Cinzel",
    fontSize: 16,

    width: "500px",
    padding: 2,
    transition: "all 0.1s ease-in-out",
    "&:active": {
      transform: "scale(0.99)",
    },
  },

  noteButton: {
    fontFamily: "Crimson Pro",
    fontSize: 16,
    textAlign: "right",
    width: "500px",
  },
};

export default styles;
