import { Box, Typography, TextField, Button, Link, Stack } from "@mui/material";
import { Link as RouterLink } from "react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRegisterMutation } from "../../api";
import { registerSchema, RegisterFormData } from "../../schemas";
import { APP_ROUTES } from "../../app";
import styles from "./styles";

const RegisterScreen = () => {
  const register = useRegisterMutation();

  const {
    register: registerField,
    handleSubmit,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = async (data: RegisterFormData) => {
    try {
      await register.mutateAsync(data);
    } catch (error) {
      // TODO: show error message in the UI
      console.error(error);
    }
  };

  return (
    <Box sx={styles.parchmentBackground} color="background.default">
      <Box sx={styles.dragonImage}></Box>
      <Box sx={styles.formContainer}>
        <Stack direction="column" spacing={2}>
          <Typography variant="h1" sx={styles.heading} color="text.primary">
            Join the Guild of Wanderers
          </Typography>

          <Typography variant="subtitle" color="text.primary">
            Embark upon your journey — inscribe your name to enter the realm
          </Typography>
        </Stack>

        <Box component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={styles.fieldContainer}>
            <Box textAlign="left">
              <Box sx={styles.rowContainer}>
                <Typography
                  variant="label"
                  sx={styles.label}
                  color="text.primary"
                >
                  Scroll of Contact
                </Typography>
                <Typography variant="note" color="text.primary">
                  Write thy enchanted scroll (email)*
                </Typography>
              </Box>
              <TextField
                fullWidth
                placeholder="ex: adventurer@realmsmail.com"
                variant="outlined"
                sx={styles.textField}
                error={!!errors.email}
                helperText={errors.email?.message}
                {...registerField("email")}
              />
            </Box>

            <Box textAlign="left">
              <Box sx={styles.rowContainer}>
                <Typography
                  variant="label"
                  sx={styles.label}
                  color="text.primary"
                >
                  Secret Rune
                </Typography>
                <Typography variant="note" color="text.primary">
                  Speak thy sacred word (password)*
                </Typography>
              </Box>
              <TextField
                fullWidth
                placeholder="Enter rune"
                type="password"
                variant="outlined"
                sx={styles.textField}
                error={!!errors.password}
                helperText={errors.password?.message}
                {...registerField("password")}
              />

              <Typography variant="note" color="text.primary">
                (Keep it safe from goblins!)
              </Typography>
            </Box>
          </Box>
          <Typography sx={styles.legal} color="text.primary">
            By sealing this pact, you swear fealty to our{" "}
            <Link href="#">Code of Honor</Link> and acknowledge the{" "}
            <Link href="#">Mystic Privacy Tome</Link>
          </Typography>
          <Box sx={{ marginBottom: 2 }}>
            <Button
              fullWidth
              sx={styles.button}
              type="submit"
              disabled={register.isPending}
            >
              {register.isPending ? "Casting the spell..." : "BEGIN THE QUEST"}
            </Button>
            <Typography sx={styles.noteButton} color="text.primary">
              No soul sacrifice required*
            </Typography>
          </Box>
          <Typography variant="note" color="text.primary">
            Already sworn your oath?{" "}
            <Link component={RouterLink} to={APP_ROUTES.LOGIN}>
              Re-enter the realm
            </Link>
          </Typography>
        </Box>
      </Box>
      <Box sx={styles.dragonOnTowerImage}></Box>
    </Box>
  );
};

export default RegisterScreen;
