export { default } from "./RegisterScreen";
