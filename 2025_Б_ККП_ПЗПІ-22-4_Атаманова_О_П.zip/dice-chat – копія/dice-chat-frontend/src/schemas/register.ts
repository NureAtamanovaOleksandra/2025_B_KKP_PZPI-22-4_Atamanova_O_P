import { z } from "zod";
import {
  MIN_PASSWORD_LENGTH,
  MAX_PASSWORD_LENGTH,
  MIN_EMAIL_LENGTH,
  MAX_EMAIL_LENGTH,
  PASSWORD_REGEX,
} from "./validationConstants";

export const registerSchema = z.object({
  email: z
    .string()
    .min(MIN_EMAIL_LENGTH, "Email must be at least 5 characters")
    .max(MAX_EMAIL_LENGTH, "Email must be less than 100 characters")
    .email("Please enter a valid email address"),
  password: z
    .string()
    .min(MIN_PASSWORD_LENGTH, "Password must be at least 8 characters")
    .max(MAX_PASSWORD_LENGTH, "Password must be less than 100 characters")
    .regex(
      PASSWORD_REGEX,
      "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
    ),
});

export type RegisterFormData = z.infer<typeof registerSchema>;
