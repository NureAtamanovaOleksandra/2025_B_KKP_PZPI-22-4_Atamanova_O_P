import axios from "axios";
import { getCookie, COOKIE_NAMES } from "../utils";

const baseURL = import.meta.env.VITE_API_URL || "http://localhost:3000/api/v1";

export const axiosInstance = axios.create({
  baseURL,
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: true,
});

axiosInstance.interceptors.request.use((config) => {
  const token = getCookie(COOKIE_NAMES.ACCESS_TOKEN);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
