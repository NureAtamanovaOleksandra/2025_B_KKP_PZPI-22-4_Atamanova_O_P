export const COOKIE_NAMES = {
  ACCESS_TOKEN: "access_token",
} as const;
