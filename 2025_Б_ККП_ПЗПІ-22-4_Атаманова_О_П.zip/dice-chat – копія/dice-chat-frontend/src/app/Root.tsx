import { useAuthStore } from "../store/authStore";
import AuthRoot from "./AuthRoot";
import GuestRoot from "./GuestRoot";

const Root = () => {
  const isUserLoggedIn = useAuthStore((state) => state.isLoggedIn);

  if (isUserLoggedIn) {
    return <AuthRoot />;
  }

  return <GuestRoot />;
};

export default Root;
