import { Navigate, Route, Routes } from "react-router";
import { HomeScreen } from "../screens";
import APP_ROUTES from "./appRoutes";

const AuthRoot = () => {
  return (
    <Routes>
      <Route path={APP_ROUTES.HOME} element={<HomeScreen />} />
      <Route path="*" element={<Navigate to={APP_ROUTES.HOME} />} />
    </Routes>
  );
};

export default AuthRoot;
