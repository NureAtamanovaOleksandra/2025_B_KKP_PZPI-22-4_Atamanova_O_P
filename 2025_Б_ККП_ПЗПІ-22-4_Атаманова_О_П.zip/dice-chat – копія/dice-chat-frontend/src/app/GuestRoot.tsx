import { Navigate, Route, Routes } from "react-router";
import { LoginScreen, RegisterScreen } from "../screens";
import APP_ROUTES from "./appRoutes";

const GuestRoot = () => {
  return (
    <Routes>
      <Route path={APP_ROUTES.LOGIN} element={<LoginScreen />} />
      <Route path={APP_ROUTES.REGISTER} element={<RegisterScreen />} />
      <Route path="*" element={<Navigate to={APP_ROUTES.LOGIN} />} />
    </Routes>
  );
};

export default GuestRoot;
