import { BrowserRouter } from "react-router";
import Root from "./Root";
import { ThemeProvider } from '@mui/material/styles';
import lightTheme from "../theme";

const App = () => {
  return (
    <ThemeProvider theme={lightTheme}>
      <BrowserRouter>
        <Root />
      </BrowserRouter>
    </ThemeProvider>
  );
};

export default App;
