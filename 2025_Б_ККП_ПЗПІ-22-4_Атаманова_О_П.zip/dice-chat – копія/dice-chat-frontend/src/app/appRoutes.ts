const APP_ROUTES = Object.freeze({
  LOGIN: "/login",
  REGISTER: "/register",
  HOME: "/",
});

export default APP_ROUTES;
