export { lightTheme as default } from "./theme";
