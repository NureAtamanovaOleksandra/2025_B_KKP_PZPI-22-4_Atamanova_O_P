const COLORS = {
    textPrimary: "#000000",
    textSecondary: "#917a46",
    textFieldBackground: "#FAF0DB",
    link: "#7C2D1F",
    linkHover: "#992d1a",
    buttonBackground: "#D3BD8C",
    buttonHover: "#b09b6d",
    buttonText: "#000000",
  };
  
  export default COLORS;