import { createTheme } from "@mui/material";
import COLORS from "./colors";

const lightTheme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: COLORS.buttonBackground,
      contrastText: COLORS.buttonText,
    },
    secondary: {
      main: COLORS.link,
    },
    text: {
      primary: COLORS.textPrimary,
      secondary: COLORS.textSecondary,
    },
    background: {
      default: COLORS.textFieldBackground,
    },
  },
  images: {
    parchmentBackground: "url('public/images/lightTheme/parchment_background.png')",
    dragon: "url('public/images/lightTheme/dragon.png')",
    dragonOnTower: "url('public/images/lightTheme/dragonOnTower.png')",
  },
  typography: {
    fontFamily: "Cinzel",
    h1: {
      fontFamily: "Cinzel",
      fontSize: 40,
    },
    subtitle: {
      fontFamily: "Crimson Pro",
      fontSize: 20,
    },
    note: {
      fontFamily: "Crimson Pro",
      fontSize: 16,
      color: "#3c2f1e",
    },
    label: {
      fontFamily: "Crimson Pro",
      fontSize: 20,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          backgroundColor: COLORS.buttonBackground,
          boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
          color: COLORS.buttonText,
          "&:hover": {
            backgroundColor: COLORS.buttonHover,
          },
        },
      },
    },
    MuiLink: {
      styleOverrides: {
        root: {
          color: COLORS.link,
          textDecorationColor: COLORS.link,
          "&:hover": {
            color: COLORS.linkHover,
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: COLORS.textFieldBackground,
          boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
          "& fieldset": {
            border: "none",
          },
        },
        input: {
          color: COLORS.textSecondary,
          fontFamily: "Crimson Pro",
        },
      },
    },
    MuiTypography: {
      defaultProps: {
        variantMapping: {
          subtitle: "h2",
        },
      },
    },
  },
});

export { lightTheme };
