declare module "@mui/material/styles" {
  interface TypographyVariants {
    subtitle: React.CSSProperties;
    note: React.CSSProperties;
    label: React.CSSProperties;
  }

  interface TypographyVariantsOptions {
    subtitle?: React.CSSProperties;
    note?: React.CSSProperties;
    label?: React.CSSProperties;
  }
  interface Theme {
    images: {
      parchmentBackground: string;
      dragon: string;
      dragonOnTower: string;
    };
  }

  interface ThemeOptions {
    images?: {
      parchmentBackground?: string;
      dragon?: string;
      dragonOnTower?: string;
    };
  }
}

declare module "@mui/material/Typography" {
  interface TypographyPropsVariantOverrides {
    subtitle: true;
    note: true;
    label: true;
  }
}


