import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Message } from './schemas/message.schema';

@Injectable()
export class MessageService {
  constructor(
    @InjectModel(Message.name) private messageModel: Model<Message>,
  ) {}

  async create(chatId: string, role: string, content: string): Promise<Message> {
    const message = new this.messageModel({
      chat: chatId,
      role,
      content,
    });
    return message.save();
  }

  async findByChatId(chatId: string): Promise<Message[]> {
    return this.messageModel.find({ chat: chatId }).exec();
  }

  async deleteByChatId(chatId: string): Promise<void> {
    await this.messageModel.deleteMany({ chat: chatId }).exec();
  }
} 