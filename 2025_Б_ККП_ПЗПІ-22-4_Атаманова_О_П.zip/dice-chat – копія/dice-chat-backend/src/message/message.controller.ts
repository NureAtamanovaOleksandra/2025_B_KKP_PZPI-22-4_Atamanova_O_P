import { Controller, Post, Body, Get, Param, Delete } from '@nestjs/common';
import { MessageService } from './message.service';

@Controller('messages')
export class MessageController {
  constructor(private readonly messageService: MessageService) {}

  @Post()
  async create(@Body() body: { chatId: string; role: string; content: string }) {
    return this.messageService.create(body.chatId, body.role, body.content);
  }

  @Get('chat/:chatId')
  async findByChatId(@Param('chatId') chatId: string) {
    return this.messageService.findByChatId(chatId);
  }

  @Delete('chat/:chatId')
  async deleteByChatId(@Param('chatId') chatId: string) {
    return this.messageService.deleteByChatId(chatId);
  }
} 