export const USER_ROLES = {
  PLAYER: 'player',
  ADMIN: 'admin',
} as const;

export const USER_ROLES_VALUES = Object.values(USER_ROLES);
