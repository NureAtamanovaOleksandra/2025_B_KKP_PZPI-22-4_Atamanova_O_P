import { Injectable } from '@nestjs/common';
import Anthropic from '@anthropic-ai/sdk';
import { ConfigService } from '@nestjs/config';
import { MessageService } from '../message/message.service';

const SYSTEM_INSTRUCTIONS = `You are an experienced Dungeon Master running a D&D 5th Edition game. Your role is to:

1. Create an immersive and engaging fantasy world
2. Guide players through their adventure with descriptive storytelling
3. Respond to player actions and decisions in a dynamic way
4. Maintain game balance while ensuring fun and excitement
5. Use the D&D 5th Edition ruleset for mechanics
6. Create memorable NPCs and interesting encounters
7. Adapt the story based on player choices
8. Provide clear options for players to proceed
9. Use dice rolls when appropriate (but don't actually roll - just describe the outcomes)
10. Keep the game flowing and engaging

Remember to:
- Be descriptive and atmospheric in your storytelling
- Give players meaningful choices
- Create a sense of danger and excitement
- Reward creative thinking
- Keep the game moving forward
- Maintain a balance between combat, exploration, and roleplay

Start by setting up an initial scenario or hook for the adventure, and then respond to the player's actions and decisions.`;

@Injectable()
export class AiService {
  private anthropic: Anthropic;

  constructor(
    private configService: ConfigService,
    private messageService: MessageService,
  ) {
    this.anthropic = new Anthropic({
      apiKey: this.configService.get<string>('ANTHROPIC_API_KEY'),
    });
  }

  async sendMessage(chatId: string, messages: any[]): Promise<any> {
    try {
      const messagesWithSystem = [
        { role: 'system', content: SYSTEM_INSTRUCTIONS },
        ...messages,
      ];

      const formattedPrompt = messagesWithSystem
        .map((msg) => {
          if (msg.role === 'system') {
            return msg.content;
          }
          return `\n\n${msg.role === 'user' ? 'Human' : 'Assistant'}: ${msg.content}`;
        })
        .join('');

      const response = await this.anthropic.messages.create({
        model: 'claude-3-opus-20240229',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: formattedPrompt,
          },
        ],
      });

      const content = response.content[0];
      if (content.type !== 'text') {
        throw new Error('Unexpected response type from Claude');
      }

      // Save the assistant's response
      await this.messageService.create(chatId, 'assistant', content.text);

      return {
        role: 'assistant',
        content: content.text,
      };
    } catch (error) {
      console.error('Error in AI chat:', error);
      throw error;
    }
  }
}
