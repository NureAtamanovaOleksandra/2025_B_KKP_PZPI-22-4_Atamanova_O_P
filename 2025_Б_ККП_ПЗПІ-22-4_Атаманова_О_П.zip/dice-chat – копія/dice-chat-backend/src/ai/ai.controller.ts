import { Controller, Post, Body } from '@nestjs/common';
import { AiService } from './ai.service';
import { MessageService } from '../message/message.service';

@Controller('ai')
export class AiController {
  constructor(
    private readonly aiService: AiService,
    private readonly messageService: MessageService,
  ) {}

  @Post('chat')
  async chat(@Body() body: { chatId: string; messages: any[] }) {
    const lastMessage = body.messages[body.messages.length - 1];
    if (lastMessage.role === 'user') {
      await this.messageService.create(body.chatId, 'user', lastMessage.content);
    }

    return this.aiService.sendMessage(body.chatId, body.messages);
  }
}
